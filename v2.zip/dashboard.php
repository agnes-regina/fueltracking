<?php
// Redirect to index.php for consistency
header('Location: index.php');
exit();
?>
